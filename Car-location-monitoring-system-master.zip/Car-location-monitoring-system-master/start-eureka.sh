java -jar platform/eureka/target/fleet-eureka-server-0.0.1-SNAPSHOT.jar
