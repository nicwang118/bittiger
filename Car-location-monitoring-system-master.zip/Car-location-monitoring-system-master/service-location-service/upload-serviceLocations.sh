curl -H "Content-Type: application/json" localhost:9001/bulk/serviceLocations -d @serviceLocations.json
