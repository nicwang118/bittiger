 java -jar dashboard/target/dashboard-1.0.0.BUILD-SNAPSHOT.jar
