/**
 * Contains domain objects.
 *
 */
package demo.model;