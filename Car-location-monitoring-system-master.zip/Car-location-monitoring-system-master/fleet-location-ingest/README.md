Service Location Ingest
==========================


## Requirements

* Java 8
* Maven

## REST Api

* POST /locations

## Rabbit

You can inspect the messages being send to RabbitMQ using it Dashboard application:

	http://localhost:15672/ (guest/guest)

