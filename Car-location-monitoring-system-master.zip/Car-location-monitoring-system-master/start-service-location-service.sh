java -jar service-location-service/target/service-location-service-1.0.0.BUILD-SNAPSHOT.jar
