java -jar platform/hystrix-dashboard/target/fleet-hystrix-dashboard-0.0.1.BUILD-SNAPSHOT.jar
