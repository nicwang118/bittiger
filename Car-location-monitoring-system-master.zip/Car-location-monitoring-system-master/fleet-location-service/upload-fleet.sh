curl -H "Content-Type: application/json" localhost:9000/fleet -d @fleet.json
